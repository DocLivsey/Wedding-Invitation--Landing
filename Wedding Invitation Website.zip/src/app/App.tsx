import { Hero } from "./components/Hero";
import { Invitation } from "./components/Invitation";
import { DateSection } from "./components/DateSection";
import { Schedule } from "./components/Schedule";
import { Venue } from "./components/Venue";
import { DressCode } from "./components/DressCode";
import { Wishes } from "./components/Wishes";
import { RSVPForm } from "./components/RSVPForm";
import { Contacts } from "./components/Contacts";

export default function App() {
  return (
    <main className="min-h-screen font-['Cormorant_Garamond'] text-gray-900 overflow-x-hidden antialiased selection:bg-[#8C2727] selection:text-white">
      <Hero />
      <Invitation />
      <DateSection />
      <Schedule />
      <Venue />
      <DressCode />
      <Wishes />
      <RSVPForm />
      <Contacts />
    </main>
  );
}
