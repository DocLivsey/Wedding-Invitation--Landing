import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Heart } from "lucide-react";

export function DateSection() {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    // Target Date: Sept 25, 2026
    const targetDate = new Date("2026-09-25T14:00:00").getTime();

    const interval = setInterval(() => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference % (1000 * 60)) / 1000),
        });
      } else {
        clearInterval(interval);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const daysOfWeek = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
  const days = [21, 22, 23, 24, 25, 26, 27];

  return (
    <section className="py-24 px-6 bg-[#F9F7F3] flex flex-col items-center border-y border-gray-200">
      <div className="max-w-3xl w-full text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-['Cormorant_Garamond'] text-gray-800 mb-4 uppercase tracking-[0.2em]">
            Сентябрь 2026
          </h2>
          <p className="text-gray-500 font-['Montserrat'] mb-12 uppercase tracking-widest text-sm">
            Наше «навсегда» начнется...
          </p>

          <div className="max-w-md mx-auto grid grid-cols-7 gap-y-6 text-xl font-['Cormorant_Garamond'] text-gray-700">
            {daysOfWeek.map((day) => (
              <div key={day} className="text-gray-400 font-['Montserrat'] text-xs font-semibold tracking-wider">
                {day}
              </div>
            ))}
            {days.map((day) => (
              <div key={day} className="relative flex justify-center items-center h-12">
                <span className={day === 25 ? "text-white z-10 font-bold text-2xl" : ""}>
                  {day}
                </span>
                {day === 25 && (
                  <motion.div
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ type: "spring", delay: 0.5 }}
                    className="absolute inset-0 flex justify-center items-center text-[#8C2727]"
                  >
                    <Heart className="w-14 h-14 fill-current" />
                  </motion.div>
                )}
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mb-12"
        >
          <p className="text-xl md:text-2xl font-['Cormorant_Garamond'] text-gray-700 mb-8 max-w-lg mx-auto italic">
            Не стройте планы на осень – мы ждем вас на нашей свадьбе!
          </p>

          <div className="flex justify-center gap-4 md:gap-8 font-['Cormorant_Garamond'] text-gray-800 text-3xl md:text-5xl">
            <div className="flex flex-col items-center w-16 md:w-24">
              <span>{timeLeft.days}</span>
              <span className="text-xs uppercase tracking-widest text-gray-400 font-['Montserrat'] mt-2">дней</span>
            </div>
            <span>:</span>
            <div className="flex flex-col items-center w-16 md:w-24">
              <span>{timeLeft.hours.toString().padStart(2, "0")}</span>
              <span className="text-xs uppercase tracking-widest text-gray-400 font-['Montserrat'] mt-2">часов</span>
            </div>
            <span>:</span>
            <div className="flex flex-col items-center w-16 md:w-24">
              <span>{timeLeft.minutes.toString().padStart(2, "0")}</span>
              <span className="text-xs uppercase tracking-widest text-gray-400 font-['Montserrat'] mt-2">минут</span>
            </div>
            <span>:</span>
            <div className="flex flex-col items-center w-16 md:w-24">
              <span>{timeLeft.seconds.toString().padStart(2, "0")}</span>
              <span className="text-xs uppercase tracking-widest text-gray-400 font-['Montserrat'] mt-2">секунд</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
