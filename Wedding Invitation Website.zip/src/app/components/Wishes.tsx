import { motion } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Wishes() {
  return (
    <section className="py-24 px-6 bg-white flex flex-col items-center border-b border-gray-100">
      <div className="max-w-4xl w-full text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-['Cormorant_Garamond'] text-gray-800 uppercase tracking-widest mb-6">
            Детали и Пожелания
          </h2>
          <div className="w-16 h-px bg-[#8C2727] mx-auto mb-8"></div>
        </motion.div>

        <div className="flex flex-col md:flex-row items-center gap-12 md:gap-24 mb-16">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex-1 w-full relative group overflow-hidden"
          >
            <div className="aspect-[4/5] overflow-hidden rounded-lg shadow-xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1584923968143-fe15986d18e9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwd2hpdGUlMjB3aW5lJTIwZ2xhc3N8ZW58MXx8fHwxNzczODY1ODE3fDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="White Wine"
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex flex-col justify-end p-6 rounded-lg">
              <span className="font-['Cormorant_Garamond'] text-4xl text-white mb-2 italic">Белое</span>
              <span className="font-['Montserrat'] text-sm tracking-wider uppercase text-gray-200">Мальчик</span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="flex-none max-w-sm mx-auto flex flex-col items-center justify-center font-['Cormorant_Garamond'] text-xl text-gray-700 italic"
          >
            <p className="mb-6 leading-relaxed">
              Мы будем благодарны, если вместо традиционных цветов вы подарите нам бутылочку хорошего вина, которая скрасит один из наших будущих семейных вечеров.
            </p>
            <p className="text-[#8C2727] font-semibold text-2xl">
              У нас есть традиция-сюрприз!
            </p>
            <p className="mt-4 text-sm font-['Montserrat'] text-gray-500 uppercase tracking-widest leading-loose">
              Если вы думаете, что первым у нас родится <span className="text-[#A0A0A0] font-bold">мальчик</span>, подарите нам <span className="italic font-bold text-gray-800">белое</span> вино.
              <br />
              Если вы уверены, что это будет <span className="text-[#8C2727] font-bold">девочка</span> — подарите <span className="italic font-bold text-[#8C2727]">красное</span>!
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex-1 w-full relative group overflow-hidden"
          >
            <div className="aspect-[4/5] overflow-hidden rounded-lg shadow-xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1761095596674-546f146fa03d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwcmVkJTIwd2luZSUyMGdsYXNzfGVufDF8fHx8MTc3Mzg2NTgxN3ww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Red Wine"
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex flex-col justify-end p-6 rounded-lg">
              <span className="font-['Cormorant_Garamond'] text-4xl text-white mb-2 italic">Красное</span>
              <span className="font-['Montserrat'] text-sm tracking-wider uppercase text-gray-200">Девочка</span>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
