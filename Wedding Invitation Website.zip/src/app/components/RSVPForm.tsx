import { useState } from "react";
import { useForm } from "react-hook-form";
import { motion } from "motion/react";

type RSVPFormData = {
  fullName: string;
  attendance: "yes" | "no";
  peopleCount: string;
  guestNames: string;
};

export function RSVPForm() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<RSVPFormData>({
    defaultValues: {
      attendance: "yes",
      peopleCount: "1",
    },
  });

  const watchAttendance = watch("attendance");

  const onSubmit = (data: RSVPFormData) => {
    console.log("Form submitted:", data);
    // In a real application, this would send data to a database
    setIsSubmitted(true);
  };

  return (
    <section className="py-24 px-6 bg-[#F9F7F3] flex flex-col items-center">
      <div className="max-w-2xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-['Cormorant_Garamond'] text-gray-800 uppercase tracking-widest mb-6">
            Анкета гостя
          </h2>
          <div className="w-16 h-px bg-[#8C2727] mx-auto mb-8"></div>
          <p className="font-['Cormorant_Garamond'] text-xl text-gray-600 italic">
            Пожалуйста, подтвердите свое присутствие до 1 августа 2026 года, чтобы мы могли планировать наше торжество наилучшим образом.
          </p>
        </motion.div>

        {isSubmitted ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white p-8 shadow-xl rounded-lg text-center border-t-4 border-[#8C2727]"
          >
            <h3 className="text-3xl font-['Cormorant_Garamond'] text-gray-800 mb-4">
              Спасибо за ваш ответ!
            </h3>
            <p className="font-['Montserrat'] text-gray-600 uppercase text-sm tracking-wider">
              Ваша анкета успешно отправлена
            </p>
          </motion.div>
        ) : (
          <motion.form
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            onSubmit={handleSubmit(onSubmit)}
            className="bg-white p-8 md:p-10 shadow-xl rounded-sm font-['Montserrat'] text-sm text-gray-700"
          >
            {/* Full Name */}
            <div className="mb-6">
              <label className="block mb-2 font-semibold uppercase tracking-widest text-xs">Ваши Фамилия и Имя</label>
              <input
                {...register("fullName", { required: "Пожалуйста, введите ваше имя" })}
                className="w-full border-b border-gray-300 px-0 py-3 focus:outline-none focus:border-[#8C2727] transition-colors bg-transparent"
                placeholder="Иванов Иван"
              />
              {errors.fullName && <p className="text-[#8C2727] text-xs mt-1">{errors.fullName.message}</p>}
            </div>

            {/* Attendance */}
            <div className="mb-8">
              <label className="block mb-4 font-semibold uppercase tracking-widest text-xs">Присутствие</label>
              <div className="flex flex-col md:flex-row gap-4">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="radio"
                    value="yes"
                    {...register("attendance")}
                    className="w-4 h-4 text-[#8C2727] focus:ring-[#8C2727] border-gray-300"
                  />
                  <span>Я приду с удовольствием</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="radio"
                    value="no"
                    {...register("attendance")}
                    className="w-4 h-4 text-[#8C2727] focus:ring-[#8C2727] border-gray-300"
                  />
                  <span>К сожалению, не смогу быть</span>
                </label>
              </div>
            </div>

            {/* Extra Info if Attending */}
            {watchAttendance === "yes" && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <div className="mb-6">
                  <label className="block mb-2 font-semibold uppercase tracking-widest text-xs">Сколько человек будет с вами?</label>
                  <select
                    {...register("peopleCount")}
                    className="w-full border-b border-gray-300 px-0 py-3 focus:outline-none focus:border-[#8C2727] bg-transparent"
                  >
                    <option value="1">Только я</option>
                    <option value="2">Нас будет двое</option>
                    <option value="3">Нас будет трое</option>
                    <option value="4">Нас будет четверо</option>
                    <option value="5+">5 и более</option>
                  </select>
                </div>

                <div className="mb-8">
                  <label className="block mb-2 font-semibold uppercase tracking-widest text-xs">Имена ваших спутников (муж/жена, дети)</label>
                  <textarea
                    {...register("guestNames")}
                    className="w-full border-b border-gray-300 px-0 py-3 focus:outline-none focus:border-[#8C2727] bg-transparent resize-none h-20"
                    placeholder="Например: Мария (жена), Саша (сын, 5 лет)"
                  />
                </div>
              </motion.div>
            )}

            <button
              type="submit"
              className="w-full py-4 bg-[#8C2727] hover:bg-[#6a1a1a] transition-colors text-white uppercase tracking-[0.2em] font-semibold mt-4"
            >
              Отправить ответ
            </button>
          </motion.form>
        )}
      </div>
    </section>
  );
}
