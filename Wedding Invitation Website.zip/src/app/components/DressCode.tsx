import { motion } from "motion/react";

export function DressCode() {
  const colors = [
    { name: "Серый", code: "#A9A9A9" },
    { name: "Темно-серый", code: "#4A4A4A" },
    { name: "Красный", code: "#8C2727" },
    { name: "Бежевый", code: "#D2B48C" },
    { name: "Пастельный розовый", code: "#F5D0C5" },
    { name: "Кремовый", code: "#FDF5E6" },
  ];

  return (
    <section className="py-24 px-6 bg-white flex flex-col items-center border-b border-gray-100">
      <div className="max-w-4xl w-full text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-['Cormorant_Garamond'] text-gray-800 uppercase tracking-widest mb-6">
            Дресс-код
          </h2>
          <div className="w-16 h-px bg-[#8C2727] mx-auto mb-8"></div>
          <p className="font-['Cormorant_Garamond'] text-xl md:text-2xl text-gray-700 italic max-w-2xl mx-auto leading-relaxed">
            Мы будем рады, если вы поддержите праздничную атмосферу и выберете нарядный, элегантный образ.
            Главное – чувствовать себя комфортно и выглядеть уместно!
            Будем признательны, если вы выберете наряды в следующих оттенках:
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="flex flex-wrap justify-center gap-6"
        >
          {colors.map((color, index) => (
            <motion.div
              key={color.code}
              initial={{ scale: 0 }}
              whileInView={{ scale: 1 }}
              viewport={{ once: true }}
              transition={{ type: "spring", delay: 0.4 + index * 0.1 }}
              className="group flex flex-col items-center gap-3"
            >
              <div
                className="w-16 h-16 md:w-20 md:h-20 rounded-full shadow-md border-2 border-white ring-1 ring-gray-200 transition-transform duration-300 group-hover:scale-110"
                style={{ backgroundColor: color.code }}
              />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
