import { motion } from "motion/react";
import { Heart } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Hero() {
  return (
    <section className="relative h-screen min-h-[600px] flex items-center justify-center overflow-hidden bg-[#F9F7F3]">
      {/* Background Decorative Element */}
      <div className="absolute inset-0 z-0 opacity-40">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1761095870661-c4ae15cac605?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwZWxlZ2FudCUyMGJlaWdlJTIwYmFja2dyb3VuZHxlbnwxfHx8fDE3NzM4NjU4MTd8MA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Elegant Background"
          className="w-full h-full object-cover"
        />
      </div>

      <div className="z-10 text-center px-4 font-['Cormorant_Garamond']">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          <p className="text-sm tracking-[0.3em] uppercase text-gray-500 mb-8 font-['Montserrat']">
            Приглашение на свадьбу
          </p>
          <h1 className="text-6xl md:text-8xl text-gray-800 mb-6 font-medium tracking-wide">
            Даниил & Софья
          </h1>
          <div className="flex items-center justify-center gap-4 text-xl md:text-2xl text-gray-600">
            <span>25</span>
            <Heart className="w-4 h-4 text-[#8C2727] fill-current" />
            <span>09</span>
            <Heart className="w-4 h-4 text-[#8C2727] fill-current" />
            <span>2026</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
