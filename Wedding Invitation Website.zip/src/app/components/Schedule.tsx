import { motion } from "motion/react";
import { Clock, Users, Cake, GlassWater, HeartHandshake } from "lucide-react";

export function Schedule() {
  const events = [
    {
      time: "14:00",
      title: "Сбор гостей",
      description: "Фуршет и приветственный напиток",
      icon: <Users className="w-6 h-6 text-[#8C2727]" />,
    },
    {
      time: "15:00",
      title: "Выездная регистрация",
      description: "Самый трогательный момент и обмен кольцами",
      icon: <HeartHandshake className="w-6 h-6 text-[#8C2727]" />,
    },
    {
      time: "16:00",
      title: "Праздничный банкет",
      description: "Вкусная еда, танцы и поздравления",
      icon: <GlassWater className="w-6 h-6 text-[#8C2727]" />,
    },
    {
      time: "21:00",
      title: "Свадебный торт",
      description: "Сладкое завершение вечера",
      icon: <Cake className="w-6 h-6 text-[#8C2727]" />,
    },
  ];

  return (
    <section className="py-24 px-6 bg-white">
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-['Cormorant_Garamond'] text-gray-800 uppercase tracking-widest">
            Тайминг дня
          </h2>
          <div className="w-16 h-px bg-[#8C2727] mx-auto mt-6"></div>
        </motion.div>

        <div className="relative border-l border-gray-300 ml-4 md:ml-10">
          {events.map((event, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="mb-12 pl-10 relative"
            >
              <div className="absolute -left-[18px] top-1 w-9 h-9 bg-white rounded-full border border-gray-300 flex items-center justify-center shadow-sm">
                {event.icon}
              </div>
              <div className="font-['Cormorant_Garamond'] text-3xl text-gray-800 mb-1">
                {event.time}
              </div>
              <h3 className="font-['Montserrat'] font-semibold text-lg text-gray-700 tracking-wide mb-2 uppercase">
                {event.title}
              </h3>
              <p className="font-['Cormorant_Garamond'] text-xl text-gray-500 italic">
                {event.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
