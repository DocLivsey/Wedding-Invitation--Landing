import { motion } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Invitation() {
  return (
    <section className="py-24 px-6 bg-white flex flex-col items-center">
      <div className="max-w-4xl w-full text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8 }}
          className="flex flex-col md:flex-row gap-8 justify-center items-center mb-16"
        >
          {/* Groom Photo */}
          <div className="flex flex-col items-center gap-4">
            <div className="w-48 h-56 md:w-64 md:h-72 p-2 bg-white shadow-xl rotate-[-2deg]">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1771495961899-6b8cd4e0b06e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwY2hpbGRob29kJTIwYm95JTIwcGhvdG98ZW58MXx8fHwxNzczODY1ODE3fDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Childhood Groom"
                className="w-full h-full object-cover grayscale"
              />
            </div>
            <span className="font-['Cormorant_Garamond'] text-3xl text-gray-800">Жених</span>
            <span className="font-['Montserrat'] uppercase tracking-widest text-sm text-gray-500">Даниил</span>
          </div>

          {/* Bride Photo */}
          <div className="flex flex-col items-center gap-4 mt-8 md:mt-0">
            <div className="w-48 h-56 md:w-64 md:h-72 p-2 bg-white shadow-xl rotate-[3deg]">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1766224241974-e6ddb60d2d4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwY2hpbGRob29kJTIwZ2lybCUyMHBob3RvfGVufDF8fHx8MTc3Mzg2NTgxN3ww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Childhood Bride"
                className="w-full h-full object-cover grayscale"
              />
            </div>
            <span className="font-['Cormorant_Garamond'] text-3xl text-gray-800">Невеста</span>
            <span className="font-['Montserrat'] uppercase tracking-widest text-sm text-gray-500">Софья</span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.3 }}
          className="font-['Cormorant_Garamond'] text-xl md:text-2xl text-gray-700 max-w-2xl mx-auto leading-relaxed"
        >
          <p className="mb-6 italic text-3xl">Да-да, это мы!</p>
          <p className="mb-4">
            Когда-то мы были детьми, беззаботными и веселыми.
            <br />
            А потом выросли, нашли друг друга...
            <br />
            и поняли, что хотим быть вместе навсегда!
          </p>
          <p>Мы приглашаем вас разделить с нами главный день в начале нашей истории любви.</p>
        </motion.div>
      </div>
    </section>
  );
}
