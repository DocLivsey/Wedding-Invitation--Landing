import { motion } from "motion/react";
import { Phone, Heart } from "lucide-react";

export function Contacts() {
  return (
    <footer className="py-24 px-6 bg-white text-center">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
      >
        <h2 className="text-4xl md:text-5xl font-['Cormorant_Garamond'] text-gray-800 mb-8">
          До встречи на нашем торжестве!
        </h2>
        <div className="flex justify-center mb-12">
          <Heart className="w-8 h-8 text-[#8C2727] fill-current" />
        </div>

        <div className="flex flex-col md:flex-row justify-center items-center gap-12 text-gray-700">
          <div className="flex flex-col items-center">
            <span className="font-['Cormorant_Garamond'] text-2xl mb-2">Жених Даниил</span>
            <a href="tel:+79991234567" className="font-['Montserrat'] tracking-widest text-sm hover:text-[#8C2727] transition-colors flex items-center gap-2">
              <Phone className="w-4 h-4" />
              +7 (999) 123-45-67
            </a>
          </div>

          <div className="hidden md:block w-px h-16 bg-gray-300"></div>

          <div className="flex flex-col items-center">
            <span className="font-['Cormorant_Garamond'] text-2xl mb-2">Невеста Софья</span>
            <a href="tel:+79997654321" className="font-['Montserrat'] tracking-widest text-sm hover:text-[#8C2727] transition-colors flex items-center gap-2">
              <Phone className="w-4 h-4" />
              +7 (999) 765-43-21
            </a>
          </div>
        </div>
      </motion.div>
    </footer>
  );
}
