import { motion } from "motion/react";
import { MapPin, Navigation } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Venue() {
  return (
    <section className="py-24 px-6 bg-[#F9F7F3] flex flex-col items-center">
      <div className="max-w-4xl w-full text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-['Cormorant_Garamond'] text-gray-800 uppercase tracking-widest mb-6">
            Локация
          </h2>
          <div className="w-16 h-px bg-[#8C2727] mx-auto mb-8"></div>
          <p className="font-['Cormorant_Garamond'] text-2xl text-gray-700 italic">
            Мы ждем вас в ресторане «Соляная Биржа»
          </p>
          <p className="font-['Montserrat'] text-gray-500 tracking-wide mt-4 uppercase text-sm font-semibold">
            г. Нижний Новгород, ул. Сибирская, 3
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative w-full h-80 md:h-[450px] shadow-lg overflow-hidden group mb-10"
        >
          {/* Decorative Map image */}
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1668187667597-22efba0e6aac?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwdmVudWUlMjBidWlsZGluZ3xlbnwxfHx8fDE3NzM4NjU4MTd8MA&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Venue Location"
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
            <div className="bg-white/90 p-6 rounded-full shadow-2xl backdrop-blur-sm animate-pulse">
              <MapPin className="w-10 h-10 text-[#8C2727]" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <a
            href="https://yandex.ru/maps/-/CDu~mZNW"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 bg-[#8C2727] hover:bg-[#6a1a1a] transition-colors text-white font-['Montserrat'] text-sm uppercase tracking-widest rounded-sm"
          >
            <Navigation className="w-4 h-4" />
            Проложить маршрут
          </a>
        </motion.div>
      </div>
    </section>
  );
}
