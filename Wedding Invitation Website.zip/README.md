
  # Wedding Invitation Website

  This is a code bundle for Wedding Invitation Website. The original project is available at https://www.figma.com/design/WuSDdAZduP9UuAeCnp2cQX/Wedding-Invitation-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  